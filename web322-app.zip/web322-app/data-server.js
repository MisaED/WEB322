var fs = require('fs');

function initialize() {
  return new Promise(function(resolve, reject) {
    fs.readFile('./data/employees.json', function(err, data) {
      if(err) reject("EXCEPTION: while reading employee.json")
      employees = JSON.parse(data);

      fs.readFile('./data/departments.json', function(err, data) {
        if(err) reject("EXCEPTION: while reading employee.json")
        departments = JSON.parse(data);
        resolve({
          status: "success",
          code: 200,
        })
      })
    })
  })
}

function getAllEmployees() {
  return new Promise(function(resolve, reject) {
    if(employees && employees.length == 0) {
      reject("EXCEPTION: no employees returned")
    }
    resolve({
      status: "success",
      code: 200,
      data: employees
    })
  })
}

function getManagers() {
  return new Promise(function(resolve, reject) {
    if(employees && employees.length == 0) {
      reject("EXCEPTION: no employees returned")
    }

    resolve({
      status: "success",
      code: 200,
      data: employees.filter(e => e.isManager && e)
    })
  })
}

function getDepartments() {
  return new Promise(function(resolve, reject) {
    console.log(departments)
    if(departments && departments.length == 0) {
      reject("EXCEPTION: no employees returned")
    }
    resolve({
      status: "success",
      code: 200,
      data: departments
    })
  })
}

module.exports = {
  initialize,
  getAllEmployees,
  getManagers,
  getDepartments
}