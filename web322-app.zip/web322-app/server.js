/*********************************************************************************
* WEB322 – Assignment 02
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any other source
* (including web sites) or distributed to other students.
*
* Name: Misato Endo      Student ID: 158516195     Date: 2021/10/10
*
* Online (Heroku) URL: https://aqueous-refuge-30289.herokuapp.com/
*
********************************************************************************/

global.employees = [];
global.departments = [];

const express = require("express");
const app = express();
const PORT = process.env.PORT || 5000;
const path = require("path");

app.use(express.static('public'));
const { initialize, getAllEmployees, getDepartments, getManagers } = require("./data-server");

app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname, 'views/home.html'))
});

app.get('/about', function (req, res) {
  res.sendFile(path.join(__dirname, 'views/about.html'))
})

app.get("/employees", function (req, res) {
  getAllEmployees()
    .then(response => res.json(response.data))
    .catch(err => res.json(err))
})

app.get("/managers", function (req, res) {
  getManagers()
    .then(response => res.json(response.data))
    .catch(err => res.json(err))
})

app.get("/departments", function (req, res) {
  getDepartments()
    .then(response => res.json(response.data))
    .catch(err => res.json(err))
})

initialize()
  .then(msg => {
    app.listen(PORT, () => console.log("app running"))
  })
  .catch(err => console.log(err))

