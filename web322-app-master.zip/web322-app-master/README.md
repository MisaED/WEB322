API_KEY=43e0c98a-4d38-4b43-b577-84e9a9dda5cd

[heroku gitlab](https://youtu.be/aKCqbSnOQWI)
[handlebars medium](https://waelyasmina.medium.com/a-guide-into-using-handlebars-with-your-express-js-application-22b944443b65)
[handlebars partials&custom helper](https://www.youtube.com/watch?v=2BoSBaWvFhM)

[bootwatch](https://bootswatch.com/)

```bash
$ docker run -p 0.0.0.0:5432:5432 --name dev-empdb -e POSTGRES_PASSWORD=password -d postgres
$ docker exec -it dev-empdb bash
$ psql -U postgres
$ create database emps;
```
